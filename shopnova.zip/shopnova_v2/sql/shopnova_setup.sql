-- ============================================================
--  ShopNova — MySQL Setup Script
--  Run this ONCE before starting the application.
--
--  HOW TO RUN:
--  1. Open MySQL Workbench → File → Open SQL Script → select this file → Run
--  OR
--  2. In terminal: mysql -u root -p < shopnova_setup.sql
-- ============================================================

-- Step 1: Create the database
CREATE DATABASE IF NOT EXISTS shopnova_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE shopnova_db;

-- Step 2: Tables are created automatically by Spring Boot (JPA)
--         BUT you can run these manually for reference or to reset:

DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS cart_items;
DROP TABLE IF EXISTS carts;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS users;

-- ── Users ───────────────────────────────────────────────────
CREATE TABLE users (
  id           BIGINT AUTO_INCREMENT PRIMARY KEY,
  first_name   VARCHAR(100) NOT NULL,
  last_name    VARCHAR(100) NOT NULL,
  email        VARCHAR(255) NOT NULL UNIQUE,
  password     VARCHAR(255) NOT NULL,   -- BCrypt hashed
  role         VARCHAR(20)  NOT NULL DEFAULT 'USER',
  created_at   DATETIME     DEFAULT CURRENT_TIMESTAMP
);

-- ── Products ─────────────────────────────────────────────────
CREATE TABLE products (
  id               BIGINT AUTO_INCREMENT PRIMARY KEY,
  name             VARCHAR(255)   NOT NULL,
  description      TEXT,
  price            DECIMAL(10,2)  NOT NULL,
  original_price   DECIMAL(10,2),
  category         VARCHAR(50)    NOT NULL,
  brand            VARCHAR(100)   NOT NULL,
  stock_quantity   INT            NOT NULL DEFAULT 0,
  image_url        VARCHAR(500),
  image_url_2      VARCHAR(500),
  badge            VARCHAR(50),
  display_type     VARCHAR(100),
  battery_life     VARCHAR(100),
  connectivity     VARCHAR(150),
  weight           VARCHAR(50),
  field_of_view    VARCHAR(50),
  rating           DOUBLE         DEFAULT 0.0,
  review_count     INT            DEFAULT 0,
  is_active        BOOLEAN        DEFAULT TRUE,
  created_at       DATETIME       DEFAULT CURRENT_TIMESTAMP
);

-- ── Carts ────────────────────────────────────────────────────
CREATE TABLE carts (
  id         BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id    BIGINT NOT NULL UNIQUE,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ── Cart Items ───────────────────────────────────────────────
CREATE TABLE cart_items (
  id         BIGINT AUTO_INCREMENT PRIMARY KEY,
  cart_id    BIGINT NOT NULL,
  product_id BIGINT NOT NULL,
  quantity   INT    NOT NULL DEFAULT 1,
  added_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (cart_id)    REFERENCES carts(id)    ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- ── Orders ───────────────────────────────────────────────────
CREATE TABLE orders (
  id               BIGINT AUTO_INCREMENT PRIMARY KEY,
  order_number     VARCHAR(50)    NOT NULL UNIQUE,
  user_id          BIGINT         NOT NULL,
  status           VARCHAR(30)    NOT NULL DEFAULT 'PENDING',
  total_amount     DECIMAL(10,2)  NOT NULL,
  shipping_address VARCHAR(255),
  shipping_city    VARCHAR(100),
  shipping_country VARCHAR(100),
  tracking_number  VARCHAR(100),
  notes            TEXT,
  created_at       DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ── Order Items ──────────────────────────────────────────────
CREATE TABLE order_items (
  id         BIGINT AUTO_INCREMENT PRIMARY KEY,
  order_id   BIGINT         NOT NULL,
  product_id BIGINT         NOT NULL,
  quantity   INT            NOT NULL,
  unit_price DECIMAL(10,2)  NOT NULL,
  FOREIGN KEY (order_id)   REFERENCES orders(id)   ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id)
);

-- ── Step 3: Insert Demo Users ────────────────────────────────
-- Passwords are BCrypt encoded:
-- admin@shopnova.com → Admin@123
-- sara@example.com   → User@123
INSERT INTO users (first_name, last_name, email, password, role) VALUES
('Ahmed',  'Admin',   'admin@shopnova.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiGAP27dJVaM9kGWaQwfVHl9xzHO', 'ADMIN'),
('Sara',   'Hassan',  'sara@example.com',   '$2a$12$KIXk.ZbPJHl4vhPb1CsK8OfFq2PflgqMNKB5L8yGRvD7LMkLGnxhi', 'USER'),
('Omar',   'Khalid',  'omar@example.com',   '$2a$12$KIXk.ZbPJHl4vhPb1CsK8OfFq2PflgqMNKB5L8yGRvD7LMkLGnxhi', 'USER'),
('Layla',  'Nour',    'layla@example.com',  '$2a$12$KIXk.ZbPJHl4vhPb1CsK8OfFq2PflgqMNKB5L8yGRvD7LMkLGnxhi', 'USER');

-- ── Step 4: Insert Smart Glasses Products ────────────────────
INSERT INTO products (name, description, price, original_price, category, brand, stock_quantity,
  image_url, badge, display_type, battery_life, connectivity, weight, field_of_view, rating, review_count)
VALUES
('Meta Ray-Ban Stories',
 'The iconic wayfarer reinvented with dual 5MP cameras, open-ear speakers, and hands-free calling. Capture photos and short videos, listen to music, and answer calls — all without reaching for your phone.',
 299.00, NULL, 'Smart', 'Meta × Ray-Ban', 45,
 'https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=800&q=80',
 'BESTSELLER', 'None', 'Up to 6 hours', 'Bluetooth 5.0', '49g', NULL, 4.4, 2840),

('Vuzix Blade 2',
 'Enterprise-grade AR smart glasses with a full-color waveguide display and Qualcomm Snapdragon processor. Runs native Android apps, supports Microsoft Teams, and integrates with warehouse management systems.',
 799.00, 999.00, 'AR', 'Vuzix', 18,
 'https://images.unsplash.com/photo-1617802690992-15d93263d3a9?w=800&q=80',
 'SALE', 'Waveguide AR', 'Up to 8 hours', 'Wi-Fi 6, BT 5.2', '85g', '20°', 4.2, 312),

('Bose Frames Tenor',
 'Premium audio sunglasses with Bose OpenAudio™ speakers that direct sound into your ears without blocking the world around you. Polarized lenses, 5.5-hour battery, and seamless voice assistant integration.',
 249.00, NULL, 'Audio', 'Bose', 60,
 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=800&q=80',
 'NEW', 'None', 'Up to 5.5 hours', 'Bluetooth 5.1', '45g', NULL, 4.6, 1520),

('Xreal Air 2 Pro',
 'Cinema-quality micro-OLED AR glasses with a massive 330-inch virtual screen. Electrochromic dimming lets you switch between transparent and opaque modes. Perfect for gaming, movies, or working from anywhere.',
 449.00, 499.00, 'AR', 'Xreal', 30,
 'https://images.unsplash.com/photo-1593508512255-86ab42a8e620?w=800&q=80',
 'NEW', 'Micro-OLED AR', 'Powered by USB-C', 'USB-C, BT 5.3', '72g', '46°', 4.5, 893),

('Oakley Radar EV Advancer',
 'Performance sport glasses with adaptive photochromic lenses that adjust from clear to dark in seconds. Prizm lens technology enhances contrast and visibility in any light condition.',
 230.00, NULL, 'Sport', 'Oakley', 75,
 'https://images.unsplash.com/photo-1508296695146-257a814070b4?w=800&q=80',
 NULL, 'None', 'N/A', 'Bluetooth (optional)', '26g', NULL, 4.7, 3210),

('Google Glass Enterprise 2',
 'Purpose-built for hands-free work on factory floors and surgical suites. Features a bone-conduction speaker, 8MP camera, and compatibility with 100+ enterprise apps. IP53 rated.',
 999.00, 1200.00, 'AR', 'Google', 12,
 'https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=800&q=80',
 'SALE', 'Prism AR Display', 'Up to 8 hours', 'Wi-Fi, BT 5.0', '46g', 'N/A', 4.1, 204),

('Snap Spectacles 4',
 'Fourth-generation Snap camera glasses with dual 3D waveguide displays for true AR. Syncs instantly to Snapchat Memories. Designed for quick social AR experiences.',
 380.00, NULL, 'AR', 'Snap', 22,
 'https://images.unsplash.com/photo-1622979135225-d2ba269cf1ac?w=800&q=80',
 'LIMITED', 'Waveguide AR', 'Up to 30 min', 'Wi-Fi, BT 5.2', '134g', '26.3°', 3.9, 567),

('Amazon Echo Frames 3rd Gen',
 'Stylish everyday glasses with Alexa built in. Ask questions, control smart home, set reminders, and make calls — all through open-ear audio. IPX4 water-resistant, lasts all day.',
 269.00, 299.00, 'Smart', 'Amazon', 55,
 'https://images.unsplash.com/photo-1582142306909-195724d33ffc?w=800&q=80',
 'SALE', 'None', 'Up to 14 hours', 'Bluetooth 5.1', '31g', NULL, 4.3, 1890),

('Epson Moverio BT-40',
 'Binocular AR glasses with twin Si-OLED displays and a large 34° FOV. Runs Android 11 and is compatible with Unity and Unreal Engine. Used in drone piloting and location-based entertainment.',
 699.00, NULL, 'AR', 'Epson', 9,
 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=800&q=80',
 NULL, 'Si-OLED AR', 'Up to 6 hours', 'Wi-Fi 5, BT 5.0', '166g', '34°', 4.0, 145),

('Fauna Audio Rimless',
 'Ultra-minimalist rimless audio glasses. Open-ear speakers deliver premium sound without earbuds. 8-hour battery, IPX5 rated, and compatible with any prescription lenses.',
 189.00, 219.00, 'Audio', 'Fauna', 40,
 'https://images.unsplash.com/photo-1516914589923-f105f1535f88?w=800&q=80',
 'SALE', 'None', 'Up to 8 hours', 'Bluetooth 5.2', '28g', NULL, 4.5, 421),

('RealWear Navigator 520',
 'Rugged head-mounted wearable for industrial use. Fully voice-controlled — completely hands-free. Certified for hazardous environments (ATEX Zone 2). Connects to Remote Expert tools.',
 1299.00, NULL, 'AR', 'RealWear', 7,
 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&q=80',
 'LIMITED', 'Micro-display', 'Up to 8 hours', 'Wi-Fi 6, BT 5.2', '259g', 'N/A', 4.3, 88),

('Huawei EyeWear 2',
 'Fashionable audio glasses designed in collaboration with GENTLE MONSTER. Dual speakers, 13-hour battery, wireless charging via magnetic case. Supports voice control and smart noise reduction.',
 299.00, NULL, 'Audio', 'Huawei', 35,
 'https://images.unsplash.com/photo-1473496169904-658ba7574b0d?w=800&q=80',
 'NEW', 'None', 'Up to 13 hours', 'Bluetooth 5.2', '36g', NULL, 4.4, 678);

-- ── Step 5: Insert Demo Orders ───────────────────────────────
INSERT INTO orders (order_number, user_id, status, total_amount,
  shipping_address, shipping_city, shipping_country, tracking_number)
VALUES
('SN-20240310-0021', 2, 'DELIVERED', 548.00, '12 Tahrir Square', 'Cairo', 'Egypt', 'EG123456789'),
('SN-20240312-0035', 2, 'SHIPPED',   449.00, '12 Tahrir Square', 'Cairo', 'Egypt', 'EG987654321'),
('SN-20240315-0048', 3, 'PROCESSING',299.00, '5 Nile Corniche',  'Alexandria', 'Egypt', NULL),
('SN-20240316-0051', 4, 'PENDING',   999.00, '88 King Faisal St','Giza', 'Egypt', NULL);

INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES
(1, 3, 1, 249.00),  -- Bose Frames
(1, 5, 1, 230.00),  -- Oakley sport
(2, 4, 1, 449.00),  -- Xreal Air 2 Pro
(3, 1, 1, 299.00),  -- Meta Ray-Ban Stories
(4, 6, 1, 999.00);  -- Google Glass Enterprise

-- ── Verify ───────────────────────────────────────────────────
SELECT 'Users:'    AS entity, COUNT(*) AS total FROM users
UNION ALL
SELECT 'Products:', COUNT(*) FROM products
UNION ALL
SELECT 'Orders:',   COUNT(*) FROM orders
UNION ALL
SELECT 'OrderItems:', COUNT(*) FROM order_items;
