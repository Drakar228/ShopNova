package com.shopnova.controller;

import com.shopnova.model.*;
import com.shopnova.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.security.Principal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Controller
class ShopController {

    @Autowired ProductRepository productRepo;
    @Autowired UserRepository userRepo;

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("featuredProducts", productRepo.findTopRated().stream().limit(4).toList());
        model.addAttribute("totalProducts", productRepo.count());
        return "index";
    }

    @GetMapping("/shop")
    public String shop(@RequestParam(required = false) String category,
                       @RequestParam(required = false) String search,
                       @RequestParam(required = false) String brand,
                       @RequestParam(required = false, defaultValue = "0") double minPrice,
                       @RequestParam(required = false, defaultValue = "9999") double maxPrice,
                       @RequestParam(required = false, defaultValue = "name") String sort,
                       Model model) {

        List<Product> products;

        if (search != null && !search.isBlank()) {
            products = productRepo.searchProducts(search.trim());
            model.addAttribute("searchQuery", search);
        } else if (category != null && !category.isBlank() && !category.equals("All")) {
            products = productRepo.findByCategoryAndIsActiveTrue(category);
            model.addAttribute("activeCategory", category);
        } else {
            products = productRepo.findByIsActiveTrue();
        }

        if (brand != null && !brand.isBlank() && !brand.equals("All")) {
            products = products.stream().filter(p -> p.getBrand().equals(brand)).collect(Collectors.toList());
            model.addAttribute("activeBrand", brand);
        }

        BigDecimal min = BigDecimal.valueOf(minPrice);
        BigDecimal max = BigDecimal.valueOf(maxPrice);
        products = products.stream()
                .filter(p -> p.getPrice().compareTo(min) >= 0 && p.getPrice().compareTo(max) <= 0)
                .collect(Collectors.toList());

        switch (sort) {
            case "price-asc"  -> products.sort(Comparator.comparing(Product::getPrice));
            case "price-desc" -> products.sort(Comparator.comparing(Product::getPrice).reversed());
            case "rating"     -> products.sort(Comparator.comparing(Product::getRating).reversed());
            default           -> products.sort(Comparator.comparing(Product::getName));
        }

        List<String> allBrands = productRepo.findByIsActiveTrue().stream()
                .map(Product::getBrand).distinct().sorted().collect(Collectors.toList());

        model.addAttribute("products", products);
        model.addAttribute("categories", List.of("All", "Meta Glasses", "VR Headsets", "AR Glasses", "Audio Glasses"));
        model.addAttribute("brands", allBrands);
        model.addAttribute("minPrice", minPrice);
        model.addAttribute("maxPrice", maxPrice);
        model.addAttribute("activeSort", sort);
        return "shop";
    }

    @GetMapping("/product/{id}")
    public String productDetail(@PathVariable Long id, Model model) {
        Product p = productRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found: " + id));
        model.addAttribute("product", p);
        List<Product> related = productRepo.findByCategoryAndIsActiveTrue(p.getCategory())
                .stream().filter(r -> !r.getId().equals(id)).limit(3).toList();
        model.addAttribute("relatedProducts", related);
        return "product-detail";
    }
}

@Controller
class AuthController {

    @Autowired UserRepository userRepo;
    @Autowired PasswordEncoder encoder;

    @GetMapping("/login")
    public String login(@RequestParam(required = false) String error,
                        @RequestParam(required = false) String logout,
                        @RequestParam(required = false) String expired,
                        Model model) {
        if (error != null)   model.addAttribute("error",   "Invalid email or password.");
        if (logout != null)  model.addAttribute("message", "You have been logged out.");
        if (expired != null) model.addAttribute("message", "Your session expired. Please log in again.");
        return "login";
    }

    @GetMapping("/register")
    public String registerForm() { return "register"; }

    @PostMapping("/register")
    public String register(@RequestParam String firstName,
                           @RequestParam String lastName,
                           @RequestParam String email,
                           @RequestParam String password,
                           RedirectAttributes ra) {
        if (userRepo.existsByEmail(email)) {
            ra.addFlashAttribute("error", "An account with this email already exists.");
            return "redirect:/register";
        }
        userRepo.save(new User(firstName, lastName, email, encoder.encode(password), "USER"));
        ra.addFlashAttribute("message", "Account created! Please log in.");
        return "redirect:/login";
    }
}

@Controller
class CartController {

    @Autowired ProductRepository productRepo;
    @Autowired OrderRepository orderRepo;
    @Autowired UserRepository userRepo;

    @SuppressWarnings("unchecked")
    private Map<Long, Integer> getSessionCart(jakarta.servlet.http.HttpSession session) {
        Map<Long, Integer> cart = (Map<Long, Integer>) session.getAttribute("cart");
        if (cart == null) { cart = new LinkedHashMap<>(); session.setAttribute("cart", cart); }
        return cart;
    }

    @GetMapping("/cart")
    public String viewCart(jakarta.servlet.http.HttpSession session, Model model) {
        Map<Long, Integer> cart = getSessionCart(session);
        List<Map<String, Object>> items = new ArrayList<>();
        BigDecimal total = BigDecimal.ZERO;

        for (Map.Entry<Long, Integer> e : cart.entrySet()) {
            Optional<Product> opt = productRepo.findById(e.getKey());
            if (opt.isPresent()) {
                Product p = opt.get();
                Map<String, Object> item = new HashMap<>();
                item.put("product", p);
                item.put("quantity", e.getValue());
                item.put("subtotal", p.getPrice().multiply(BigDecimal.valueOf(e.getValue())));
                items.add(item);
                total = total.add(p.getPrice().multiply(BigDecimal.valueOf(e.getValue())));
            }
        }

        model.addAttribute("cartItems", items);
        model.addAttribute("cartTotal", total);
        model.addAttribute("shipping", total.compareTo(BigDecimal.valueOf(300)) >= 0 ? BigDecimal.ZERO : BigDecimal.valueOf(15));
        return "cart";
    }

    @PostMapping("/cart/add")
    public String addToCart(@RequestParam Long productId,
                            @RequestParam(defaultValue = "1") int quantity,
                            jakarta.servlet.http.HttpSession session,
                            RedirectAttributes ra) {
        getSessionCart(session).merge(productId, quantity, Integer::sum);
        ra.addFlashAttribute("cartSuccess", "Added to cart!");
        return "redirect:/shop";
    }

    @PostMapping("/cart/update")
    public String updateCart(@RequestParam Long productId,
                             @RequestParam int quantity,
                             jakarta.servlet.http.HttpSession session) {
        Map<Long, Integer> cart = getSessionCart(session);
        if (quantity <= 0) cart.remove(productId);
        else cart.put(productId, quantity);
        return "redirect:/cart";
    }

    @PostMapping("/cart/remove")
    public String removeFromCart(@RequestParam Long productId,
                                 jakarta.servlet.http.HttpSession session) {
        getSessionCart(session).remove(productId);
        return "redirect:/cart";
    }

    @GetMapping("/checkout")
    public String checkoutPage(jakarta.servlet.http.HttpSession session, Model model, Principal principal) {
        if (principal == null) return "redirect:/login";
        Map<Long, Integer> cart = getSessionCart(session);
        if (cart.isEmpty()) return "redirect:/cart";
        BigDecimal total = cart.entrySet().stream()
                .map(e -> productRepo.findById(e.getKey())
                        .map(p -> p.getPrice().multiply(BigDecimal.valueOf(e.getValue())))
                        .orElse(BigDecimal.ZERO))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        model.addAttribute("cartTotal", total);
        model.addAttribute("itemCount", cart.values().stream().mapToInt(i -> i).sum());
        return "checkout";
    }

    @PostMapping("/checkout")
    public String placeOrder(@RequestParam String address,
                             @RequestParam String city,
                             @RequestParam String country,
                             jakarta.servlet.http.HttpSession session,
                             Principal principal,
                             RedirectAttributes ra) {
        if (principal == null) return "redirect:/login";
        Map<Long, Integer> cart = getSessionCart(session);
        if (cart.isEmpty()) return "redirect:/cart";

        User user = userRepo.findByEmail(principal.getName()).orElseThrow();
        Order order = new Order();
        order.setUser(user);
        order.setOrderNumber("SN-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"))
                + "-" + String.format("%04d", (int)(Math.random() * 9999)));
        order.setShippingAddress(address);
        order.setShippingCity(city);
        order.setShippingCountry(country);
        order.setStatus(Order.Status.PROCESSING);

        BigDecimal total = BigDecimal.ZERO;
        for (Map.Entry<Long, Integer> e : cart.entrySet()) {
            Product p = productRepo.findById(e.getKey()).orElse(null);
            if (p == null) continue;
            order.getItems().add(new OrderItem(order, p, e.getValue(), p.getPrice()));
            total = total.add(p.getPrice().multiply(BigDecimal.valueOf(e.getValue())));
        }
        order.setTotalAmount(total);
        orderRepo.save(order);
        session.removeAttribute("cart");

        ra.addFlashAttribute("orderNumber", order.getOrderNumber());
        ra.addFlashAttribute("orderTotal", total);
        return "redirect:/orders";
    }
}

@Controller
class OrderController {
    @Autowired OrderRepository orderRepo;
    @Autowired UserRepository userRepo;

    @GetMapping("/orders")
    public String myOrders(Principal principal, Model model) {
        if (principal == null) return "redirect:/login";
        User user = userRepo.findByEmail(principal.getName()).orElseThrow();
        model.addAttribute("orders", orderRepo.findByUserOrderByCreatedAtDesc(user));
        return "orders";
    }
}

@Controller
@RequestMapping("/admin")
class AdminController {
    @Autowired ProductRepository productRepo;
    @Autowired OrderRepository orderRepo;
    @Autowired UserRepository userRepo;

    @GetMapping({"", "/"})
    public String dashboard(Model model) {
        model.addAttribute("totalRevenue", orderRepo.getTotalRevenue());
        model.addAttribute("totalOrders", orderRepo.count());
        model.addAttribute("totalUsers", userRepo.count());
        model.addAttribute("totalProducts", productRepo.count());
        model.addAttribute("activeOrders", orderRepo.countActiveOrders());
        model.addAttribute("lowStock", productRepo.countLowStock());
        model.addAttribute("recentOrders", orderRepo.findAll().stream()
                .sorted(Comparator.comparing(Order::getCreatedAt).reversed()).limit(8).toList());
        model.addAttribute("products", productRepo.findAll());
        model.addAttribute("users", userRepo.findAll());
        return "admin/dashboard";
    }

    @GetMapping("/products")
    public String manageProducts(Model model) {
        model.addAttribute("products", productRepo.findAll());
        return "admin/products";
    }

    @PostMapping("/products/toggle/{id}")
    public String toggleProduct(@PathVariable Long id) {
        productRepo.findById(id).ifPresent(p -> { p.setIsActive(!p.getIsActive()); productRepo.save(p); });
        return "redirect:/admin/products";
    }

    @PostMapping("/orders/{id}/status")
    public String updateOrderStatus(@PathVariable Long id, @RequestParam String status) {
        orderRepo.findById(id).ifPresent(o -> { o.setStatus(Order.Status.valueOf(status)); o.setUpdatedAt(LocalDateTime.now()); orderRepo.save(o); });
        return "redirect:/admin";
    }

    @GetMapping("/orders")
    public String manageOrders(Model model) {
        model.addAttribute("orders", orderRepo.findAll().stream()
                .sorted(Comparator.comparing(Order::getCreatedAt).reversed()).toList());
        return "admin/orders";
    }
}
