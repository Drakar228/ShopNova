package com.shopnova.config;

import com.shopnova.model.Order;
import com.shopnova.model.OrderItem;
import com.shopnova.model.Product;
import com.shopnova.model.User;
import com.shopnova.repository.OrderRepository;
import com.shopnova.repository.ProductRepository;
import com.shopnova.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Component
public class DataSeeder implements CommandLineRunner {

    @Autowired private ProductRepository productRepo;
    @Autowired private UserRepository userRepo;
    @Autowired private OrderRepository orderRepo;
    @Autowired private PasswordEncoder encoder;

    @Override
    public void run(String... args) {
        seedUsers();
        seedProducts();
        seedOrders();
    }

    private void seedUsers() {
        if (userRepo.count() > 0) return;
        userRepo.save(new User("Ahmed", "Admin", "admin@shopnova.com", encoder.encode("Admin@123"), "ADMIN"));
        userRepo.save(new User("Sara",  "Hassan", "sara@example.com",  encoder.encode("Admin@123"), "USER"));
        userRepo.save(new User("Omar",  "Khalid", "omar@example.com",  encoder.encode("Admin@123"), "USER"));
    }

    private void seedProducts() {
        if (productRepo.count() > 0) return;

        Object[][] data = {
            {"Meta Ray-Ban Wayfarer","The most iconic collaboration in wearable tech. These classic Wayfarer frames hide dual 12MP cameras, open-ear speakers, and a 4-mic array for crystal-clear calls. Capture first-person moments hands-free, stream music, and take calls without ever touching your phone.",299.00,null,"Meta Glasses","Meta x Ray-Ban",45,"https://images.unsplash.com/photo-1574258495973-f010dfbb5371?w=800&q=85","BESTSELLER","None","Up to 4 hours active / 32 hours standby","Bluetooth 5.3","49g",null,4.6,3840},
            {"Meta Ray-Ban Headliner","Meta's boldest design yet — the oversized Headliner frame brings the same dual-camera system and open-ear audio to a fashion-forward silhouette. Ultra-wide 12MP camera captures everything in your peripheral. IPX4 splash resistant.",329.00,null,"Meta Glasses","Meta x Ray-Ban",30,"https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=800&q=85","NEW","None","Up to 4 hours active","Bluetooth 5.3","51g",null,4.5,1240},
            {"Meta Quest 3","Meta's most powerful mixed reality headset. Pancake lens optics deliver razor-sharp visuals at 2064x2208 per eye. Snapdragon XR2 Gen 2 chip handles photorealistic passthrough, spatial audio, and AAA gaming simultaneously. Access 500+ apps and games.",499.00,549.00,"VR Headsets","Meta",28,"https://images.unsplash.com/photo-1622979135225-d2ba269cf1ac?w=800&q=85","SALE","LCD Mixed Reality","Up to 2.2 hours","Wi-Fi 6E, BT 5.2","515g","110°",4.7,5620},
            {"Meta Quest 3S","The affordable entry into Meta's mixed reality ecosystem. Same Snapdragon XR2 Gen 2 processor as Quest 3, redesigned optics at a lower price. Full color passthrough, hand tracking, and access to the complete Quest library.",299.00,null,"VR Headsets","Meta",55,"https://images.unsplash.com/photo-1593508512255-86ab42a8e620?w=800&q=85","NEW","LCD Mixed Reality","Up to 2.5 hours","Wi-Fi 6E, BT 5.2","514g","96°",4.5,2180},
            {"Apple Vision Pro","Apple's spatial computing platform. Micro-OLED displays deliver 23 million pixels — more than a 4K TV for each eye. EyeSight makes eye contact feel natural. visionOS runs your entire app library in infinite space. Works seamlessly with Mac, iPhone, and iPad.",3499.00,null,"VR Headsets","Apple",8,"https://images.unsplash.com/photo-1617802690992-15d93263d3a9?w=800&q=85","LIMITED","Micro-OLED Spatial","Up to 2 hours + external battery","Wi-Fi 6, BT 5.3","600g","100°+",4.8,980},
            {"Xreal Air 2 Ultra","The most advanced consumer AR glasses. Electrochromic lens dimming, spatial hand-tracking, and a 67° field of view create true mixed reality without a headset. Connects to iPhone, Mac, Android, and PC. The 520-inch virtual screen is stunning.",699.00,799.00,"AR Glasses","Xreal",18,"https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=800&q=85","SALE","Micro-OLED AR","USB-C powered","USB-C 3.2, BT 5.3","80g","67°",4.5,720},
            {"Xreal Air 2","Lightweight cinema glasses that turn your phone or laptop into a 330-inch personal screen. Micro-OLED panels with 500 nit brightness and 120Hz refresh rate. Fold-flat titanium frame weighs just 72g.",349.00,399.00,"AR Glasses","Xreal",40,"https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=800&q=85","SALE","Micro-OLED AR","USB-C powered","USB-C 3.2","72g","46°",4.4,1350},
            {"Google Glass Enterprise 2","The gold standard for industrial AR. Worn by surgeons, factory technicians, and field engineers worldwide. Overlays real-time data and video calls in your line of sight. IP53 rated, 8+ hours battery, integrates with SAP, Oracle, and Microsoft Dynamics.",999.00,1200.00,"AR Glasses","Google",12,"https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&q=85","SALE","Prism Waveguide AR","Up to 8 hours","Wi-Fi 5, BT 5.0","46g","N/A",4.2,310},
            {"Vuzix Blade 2","Enterprise AR glasses with a full-color waveguide display and Android OS. Qualcomm Snapdragon runs native apps including Microsoft Teams, remote assistance, and barcode scanning. Snap-on prescription insert available.",799.00,null,"AR Glasses","Vuzix",15,"https://images.unsplash.com/photo-1508296695146-257a814070b4?w=800&q=85",null,"Waveguide AR","Up to 8 hours","Wi-Fi 6, BT 5.2","85g","20°",4.1,285},
            {"Epson Moverio BT-45CS","Binocular Si-OLED AR display optimized for enterprise and drone piloting. Android 11 with Google Play Store. 34° field of view and 1280x720 per-eye resolution. Runs Unity and Unreal apps natively.",649.00,null,"AR Glasses","Epson",9,"https://images.unsplash.com/photo-1516914589923-f105f1535f88?w=800&q=85",null,"Si-OLED AR","Up to 6 hours","Wi-Fi 5, BT 5.0","169g","34°",4.0,160},
            {"Snap Spectacles 5","Fifth-generation Snap camera glasses with dual 3D waveguide AR displays. Captures Spatial Snaps with depth metadata. Titanium frame, 45-minute battery, water-resistant. Syncs to Snapchat and Snap's Lens Studio.",449.00,null,"AR Glasses","Snap",14,"https://images.unsplash.com/photo-1582142306909-195724d33ffc?w=800&q=85","LIMITED","Waveguide AR","Up to 45 min","Wi-Fi 6, BT 5.3","128g","26.3°",4.0,410},
            {"Bose Frames Tempo","Sport audio glasses for runners and cyclists. Rubberized grip, polarized lenses, sweat-resistant build. Bose OpenAudio delivers powerful bass without blocking environmental sounds for safety. IPX4 rated.",249.00,null,"Audio Glasses","Bose",55,"https://images.unsplash.com/photo-1473496169904-658ba7574b0d?w=800&q=85","NEW","None","Up to 8 hours","Bluetooth 5.1","45g",null,4.7,2100},
            {"Bose Frames Tenor","Refined rectangular frames with Bose's open-ear audio. Micro-drivers deliver room-filling sound. Included polarized lenses, seamless Siri and Google Assistant integration. Clear microphone handles calls in wind and noise.",229.00,249.00,"Audio Glasses","Bose",60,"https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=800&q=85","SALE","None","Up to 5.5 hours","Bluetooth 5.1","45g",null,4.6,1890},
            {"Amazon Echo Frames 3rd Gen","Always-On Alexa glasses. Ask questions, control smart home, play music, and make calls through open-ear audio. IPX4 water-resistant. VIP Filter controls which notifications reach you. Works with any prescription lenses.",269.00,299.00,"Audio Glasses","Amazon",50,"https://images.unsplash.com/photo-1574258495973-f010dfbb5371?w=800&q=85","SALE","None","Up to 14 hours","Bluetooth 5.1","31g",null,4.3,2340},
            {"Huawei EyeWear 2 Pro","Co-designed with GENTLE MONSTER. Dual speakers create a wide soundstage. Wireless charging case extends to 36 hours total. Smart noise reduction for calls. Available in Square, Round, and D-shaped designer frames.",319.00,null,"Audio Glasses","Huawei",35,"https://images.unsplash.com/photo-1617802690992-15d93263d3a9?w=800&q=85","NEW","None","Up to 13 hours","Bluetooth 5.2","36g",null,4.4,780},
            {"Fauna Audio Rimless","Scandinavian-designed rimless audio glasses with virtually invisible speakers in ultra-slim temples. Compatible with any prescription lenses worldwide. Made from plant-based acetate. The world's most discreet audio glasses.",189.00,219.00,"Audio Glasses","Fauna",40,"https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=800&q=85","SALE","None","Up to 8 hours","Bluetooth 5.2","28g",null,4.5,530},
            {"RealWear Navigator 520","The most rugged industrial AR headset in the world. 100% voice-controlled — fully hands-free. ATEX Zone 2 certified for flammable environments. Connects to TeamViewer, Microsoft Teams, Zoom, and 30+ industrial platforms.",1299.00,null,"AR Glasses","RealWear",7,"https://images.unsplash.com/photo-1593508512255-86ab42a8e620?w=800&q=85","LIMITED","Micro-display","Up to 8 hours","Wi-Fi 6, BT 5.2","259g","N/A",4.3,95},
            {"Microsoft HoloLens 2","The most advanced holographic AR headset for enterprise. Instinctive hand and eye tracking, zero controllers. Overlays photorealistic 3D holograms at life-size scale. Used by Boeing, Airbus, and the US Army. Azure Spatial Anchors enable shared multi-user experiences.",3500.00,null,"AR Glasses","Microsoft",5,"https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=800&q=85","LIMITED","Waveguide Holographic","Up to 3 hours","Wi-Fi 5, BT 5.0","566g","52°",4.3,145},
            {"Samsung Galaxy XR","Samsung's first standalone mixed reality headset on Android XR. Snapdragon XR2+ Gen 2, micro-OLED displays at 3500 PPI, full Google integration. Access Google Maps, YouTube, and Play Store in spatial computing.",599.00,null,"VR Headsets","Samsung",20,"https://images.unsplash.com/photo-1622979135225-d2ba269cf1ac?w=800&q=85","NEW","Micro-OLED XR","Up to 3 hours","Wi-Fi 7, BT 5.4","420g","120°",4.6,340},
            {"PlayStation VR2","Sony's second-generation VR headset for PS5. Eye tracking, adaptive triggers on Sense controllers, 4K HDR OLED at 90/120Hz. Headset feedback adds physical sensation to gameplay. 40+ titles including Horizon and Gran Turismo.",549.00,599.00,"VR Headsets","Sony",22,"https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=800&q=85","SALE","4K HDR OLED","Up to 2.5 hours","USB-C to PS5","560g","110°",4.5,2870},
            {"Ray-Ban Meta Smart Glasses Standard","The everyday version of the Meta x Ray-Ban collaboration. Classic rectangular frame available in 150+ lens and frame color combinations. Same AI features as Wayfarer — hands-free calling, music, and photo capture. Prescription-ready.",279.00,null,"Meta Glasses","Meta x Ray-Ban",65,"https://images.unsplash.com/photo-1508296695146-257a814070b4?w=800&q=85",null,"None","Up to 4 hours","Bluetooth 5.3","48g",null,4.5,2100}
        };

        for (Object[] d : data) {
            Product p = new Product();
            p.setName((String) d[0]);
            p.setDescription((String) d[1]);
            p.setPrice(BigDecimal.valueOf((double) d[2]));
            if (d[3] != null) p.setOriginalPrice(BigDecimal.valueOf((double) d[3]));
            p.setCategory((String) d[4]);
            p.setBrand((String) d[5]);
            p.setStockQuantity((int) d[6]);
            p.setImageUrl((String) d[7]);
            p.setBadge((String) d[8]);
            p.setDisplayType((String) d[9]);
            p.setBatteryLife((String) d[10]);
            p.setConnectivity((String) d[11]);
            p.setWeight((String) d[12]);
            p.setFieldOfView((String) d[13]);
            p.setRating((double) d[14]);
            p.setReviewCount((int) d[15]);
            productRepo.save(p);
        }
    }

    private void seedOrders() {
        if (orderRepo.count() > 0) return;
        User sara = userRepo.findByEmail("sara@example.com").orElse(null);
        User omar = userRepo.findByEmail("omar@example.com").orElse(null);
        if (sara == null || omar == null) return;

        java.util.List<Product> all = productRepo.findAll();
        Product p1 = all.stream().filter(p -> p.getName().contains("Meta Ray-Ban Wayfarer")).findFirst().orElse(null);
        Product p2 = all.stream().filter(p -> p.getName().contains("Bose Frames Tempo")).findFirst().orElse(null);
        Product p3 = all.stream().filter(p -> p.getName().contains("Meta Quest 3S")).findFirst().orElse(null);
        if (p1 == null || p2 == null || p3 == null) return;

        Order o1 = new Order();
        o1.setOrderNumber("SN-20240310-0021");
        o1.setUser(sara);
        o1.setStatus(Order.Status.DELIVERED);
        o1.setTotalAmount(BigDecimal.valueOf(548.00));
        o1.setShippingAddress("12 Tahrir Square");
        o1.setShippingCity("Cairo");
        o1.setShippingCountry("Egypt");
        o1.setTrackingNumber("EG123456789");
        o1.setCreatedAt(LocalDateTime.now().minusDays(14));
        o1.setUpdatedAt(LocalDateTime.now().minusDays(10));
        o1.getItems().add(new OrderItem(o1, p1, 1, p1.getPrice()));
        o1.getItems().add(new OrderItem(o1, p2, 1, p2.getPrice()));
        orderRepo.save(o1);

        Order o2 = new Order();
        o2.setOrderNumber("SN-20240315-0048");
        o2.setUser(omar);
        o2.setStatus(Order.Status.SHIPPED);
        o2.setTotalAmount(p3.getPrice());
        o2.setShippingAddress("5 Nile Corniche");
        o2.setShippingCity("Alexandria");
        o2.setShippingCountry("Egypt");
        o2.setTrackingNumber("EG987654321");
        o2.setCreatedAt(LocalDateTime.now().minusDays(5));
        o2.setUpdatedAt(LocalDateTime.now().minusDays(3));
        o2.getItems().add(new OrderItem(o2, p3, 1, p3.getPrice()));
        orderRepo.save(o2);
    }
}
