package com.shopnova.repository;

import com.shopnova.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    List<Product> findByIsActiveTrue();

    List<Product> findByCategoryAndIsActiveTrue(String category);

    List<Product> findByBrandAndIsActiveTrue(String brand);

    @Query("SELECT p FROM Product p WHERE p.isActive = true AND " +
           "(LOWER(p.name) LIKE LOWER(CONCAT('%', :q, '%')) OR " +
           " LOWER(p.brand) LIKE LOWER(CONCAT('%', :q, '%')) OR " +
           " LOWER(p.category) LIKE LOWER(CONCAT('%', :q, '%')))")
    List<Product> searchProducts(@Param("q") String query);

    @Query("SELECT p FROM Product p WHERE p.isActive = true ORDER BY p.rating DESC")
    List<Product> findTopRated();

    @Query("SELECT p FROM Product p WHERE p.badge = 'BESTSELLER' AND p.isActive = true")
    List<Product> findBestsellers();

    @Query("SELECT COUNT(p) FROM Product p WHERE p.stockQuantity < 5 AND p.stockQuantity > 0")
    Long countLowStock();
}
