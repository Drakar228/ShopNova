package com.shopnova;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/**
 * ShopNova - Smart Glasses E-Commerce
 * Main application entry point.
 * Extends SpringBootServletInitializer so it can also be deployed on external Tomcat.
 */
@SpringBootApplication
public class ShopNovaApplication extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(ShopNovaApplication.class);
    }

    public static void main(String[] args) {
        SpringApplication.run(ShopNovaApplication.class, args);
    }
}
