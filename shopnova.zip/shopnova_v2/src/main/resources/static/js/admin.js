// ShopNova — Admin Dashboard JS

// ── Date display ─────────────────────────────────────────
const dateEl = document.getElementById('adminDate');
if (dateEl) {
  const now = new Date();
  dateEl.textContent = now.toLocaleDateString('en-US', { weekday:'long', year:'numeric', month:'long', day:'numeric' });
}

// ── Revenue Chart (demo monthly data) ────────────────────
const chartEl = document.getElementById('revenueChart');
const labelsEl = document.getElementById('chartLabels');
if (chartEl) {
  const months = ['Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar','Apr','May','Jun'];
  const values = [1850, 2200, 1980, 2750, 3100, 2890, 3450, 2980, 3800, 4100, 3750, 4500];
  const max = Math.max(...values);

  months.forEach((month, i) => {
    const wrap = document.createElement('div');
    wrap.className = 'chart-bar-wrap';
    wrap.title = `${month}: $${values[i].toLocaleString()}`;

    const valLabel = document.createElement('div');
    valLabel.className = 'chart-val';
    valLabel.style.cssText = 'font-size:0.6rem;color:var(--text3);';
    valLabel.textContent = '$' + (values[i] / 1000).toFixed(1) + 'k';

    const bar = document.createElement('div');
    bar.className = 'chart-bar';
    bar.style.height = '0px';
    bar.style.transition = `height 0.6s cubic-bezier(.25,.8,.25,1) ${i * 0.05}s`;

    const label = document.createElement('div');
    label.className = 'chart-label';
    label.textContent = month;

    wrap.appendChild(valLabel);
    wrap.appendChild(bar);
    wrap.appendChild(label);
    chartEl.appendChild(wrap);

    // Animate in
    requestAnimationFrame(() => {
      setTimeout(() => {
        bar.style.height = ((values[i] / max) * 130) + 'px';
      }, 100);
    });
  });
}

// ── Order Status Breakdown ────────────────────────────────
const statusEl = document.getElementById('statusBreakdown');
if (statusEl) {
  const statusRows = document.querySelectorAll('.order-status-data');
  const counts = { PENDING:0, PROCESSING:0, SHIPPED:0, DELIVERED:0, CANCELLED:0 };
  statusRows.forEach(r => {
    const s = r.dataset.status;
    if (counts[s] !== undefined) counts[s]++;
  });

  const colors = {
    DELIVERED: '#10b981', SHIPPED: '#3b82f6',
    PROCESSING: '#f59e0b', PENDING: '#64748b', CANCELLED: '#ef4444'
  };

  const total = Object.values(counts).reduce((a,b) => a+b, 0) || 1;

  Object.entries(counts).forEach(([status, count]) => {
    if (count === 0) return;
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;align-items:center;gap:0.75rem;margin-bottom:0.6rem;';

    const label = document.createElement('span');
    label.style.cssText = `font-size:0.78rem;color:var(--text2);width:100px;flex-shrink:0;`;
    label.textContent = status;

    const barWrap = document.createElement('div');
    barWrap.style.cssText = 'flex:1;height:8px;background:var(--border);border-radius:4px;overflow:hidden;';

    const bar = document.createElement('div');
    bar.style.cssText = `height:100%;width:0%;background:${colors[status]};border-radius:4px;transition:width 0.8s ease;`;
    barWrap.appendChild(bar);

    const cnt = document.createElement('span');
    cnt.style.cssText = 'font-size:0.78rem;color:var(--text3);width:30px;text-align:right;';
    cnt.textContent = count;

    row.appendChild(label);
    row.appendChild(barWrap);
    row.appendChild(cnt);
    statusEl.appendChild(row);

    setTimeout(() => { bar.style.width = ((count / total) * 100) + '%'; }, 200);
  });
}

// ── Auto-hide alerts ─────────────────────────────────────
document.querySelectorAll('.alert').forEach(el => {
  setTimeout(() => { el.style.transition='opacity 0.5s'; el.style.opacity='0'; setTimeout(()=>el.remove(),500); }, 5000);
});
