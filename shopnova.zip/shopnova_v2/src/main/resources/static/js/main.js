document.querySelectorAll('.flash-success, .alert').forEach(el => {
  setTimeout(() => { el.style.transition='opacity 0.5s'; el.style.opacity='0'; setTimeout(()=>el.remove(),500); }, 4500);
});

const cardInput = document.querySelector('input[placeholder*="4242"]');
if (cardInput) {
  cardInput.addEventListener('input', e => {
    let v = e.target.value.replace(/\D/g,'').slice(0,16);
    e.target.value = v.replace(/(.{4})/g,'$1 ').trim();
  });
}

const expiryInput = document.querySelector('input[placeholder="MM/YY"]');
if (expiryInput) {
  expiryInput.addEventListener('input', e => {
    let v = e.target.value.replace(/\D/g,'').slice(0,4);
    if (v.length >= 3) v = v.slice(0,2)+'/'+v.slice(2);
    e.target.value = v;
  });
}

const searchField = document.getElementById('searchField');
if (searchField) {
  let timer;
  searchField.addEventListener('input', () => {
    clearTimeout(timer);
    timer = setTimeout(() => searchField.closest('form').submit(), 700);
  });
}

if (typeof QRCode !== 'undefined') {
  document.querySelectorAll('.qr-code[data-url]').forEach(el => {
    new QRCode(el, {
      text: window.location.origin + el.dataset.url,
      width: 90, height: 90,
      colorDark: '#f1f5f9', colorLight: '#111620',
      correctLevel: QRCode.CorrectLevel.M
    });
  });
}
