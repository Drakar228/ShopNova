USE shopnova_db;

SET SQL_SAFE_UPDATES = 0;

DELETE FROM order_items;
DELETE FROM orders;
DELETE FROM cart_items;
DELETE FROM carts;
DELETE FROM users;

SET SQL_SAFE_UPDATES = 1;

INSERT INTO users (first_name, last_name, email, password, role) VALUES
('Ahmed', 'Admin', 'admin@shopnova.com', '$2a$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ADMIN'),
('Sara',  'Hassan', 'sara@example.com',  '$2a$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'USER'),
('Omar',  'Khalid', 'omar@example.com',  '$2a$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'USER');