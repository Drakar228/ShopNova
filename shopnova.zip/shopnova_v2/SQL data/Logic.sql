USE shopnova_db;

DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS cart_items;
DROP TABLE IF EXISTS carts;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id         BIGINT AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(100) NOT NULL,
  last_name  VARCHAR(100) NOT NULL,
  email      VARCHAR(255) NOT NULL UNIQUE,
  password   VARCHAR(255) NOT NULL,
  role       VARCHAR(20)  NOT NULL DEFAULT 'USER',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE products (
  id             BIGINT AUTO_INCREMENT PRIMARY KEY,
  name           VARCHAR(255)  NOT NULL,
  description    TEXT,
  price          DECIMAL(10,2) NOT NULL,
  original_price DECIMAL(10,2),
  category       VARCHAR(50)   NOT NULL,
  brand          VARCHAR(100)  NOT NULL,
  stock_quantity INT           NOT NULL DEFAULT 0,
  image_url      VARCHAR(500),
  image_url_2    VARCHAR(500),
  badge          VARCHAR(50),
  display_type   VARCHAR(100),
  battery_life   VARCHAR(100),
  connectivity   VARCHAR(150),
  weight         VARCHAR(50),
  field_of_view  VARCHAR(50),
  rating         DOUBLE  DEFAULT 0.0,
  review_count   INT     DEFAULT 0,
  is_active      BOOLEAN DEFAULT TRUE,
  created_at     DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE carts (
  id         BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id    BIGINT NOT NULL UNIQUE,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE cart_items (
  id         BIGINT AUTO_INCREMENT PRIMARY KEY,
  cart_id    BIGINT NOT NULL,
  product_id BIGINT NOT NULL,
  quantity   INT    NOT NULL DEFAULT 1,
  added_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (cart_id)    REFERENCES carts(id)    ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE TABLE orders (
  id               BIGINT AUTO_INCREMENT PRIMARY KEY,
  order_number     VARCHAR(50)   NOT NULL UNIQUE,
  user_id          BIGINT        NOT NULL,
  status           VARCHAR(30)   NOT NULL DEFAULT 'PENDING',
  total_amount     DECIMAL(10,2) NOT NULL,
  shipping_address VARCHAR(255),
  shipping_city    VARCHAR(100),
  shipping_country VARCHAR(100),
  tracking_number  VARCHAR(100),
  notes            TEXT,
  created_at       DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE order_items (
  id         BIGINT AUTO_INCREMENT PRIMARY KEY,
  order_id   BIGINT        NOT NULL,
  product_id BIGINT        NOT NULL,
  quantity   INT           NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (order_id)   REFERENCES orders(id)   ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id)
);

INSERT INTO users (first_name, last_name, email, password, role) VALUES
('Ahmed', 'Admin',   'admin@shopnova.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiGAP27dJVaM9kGWaQwfVHl9xzHO', 'ADMIN'),
('Sara',  'Hassan',  'sara@example.com',   '$2a$12$KIXk.ZbPJHl4vhPb1CsK8OfFq2PflgqMNKB5L8yGRvD7LMkLGnxhi', 'USER'),
('Omar',  'Khalid',  'omar@example.com',   '$2a$12$KIXk.ZbPJHl4vhPb1CsK8OfFq2PflgqMNKB5L8yGRvD7LMkLGnxhi', 'USER');