package com.shopnova;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopnovaApplication {

    public static void main(String[] args) {
        SpringApplication.run(ShopnovaApplication.class, args);
    }

}
